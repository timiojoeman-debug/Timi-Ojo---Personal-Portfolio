grid = [["W" for _ in range(10)] for _ in range(10)]
grid[3][5] = "B"
grid[2][5] = "Robot"

print(grid)
