<?php
$servername = "localhost";
$username = "root"; // Change if needed
$password = "";
$dbname = "bookstore";

// Connect to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);

// Check Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Default books array
$defaultBooks = [
    ["title" => "To Kill a Mockingbird", "author" => "Harper Lee", "price" => 8.49, "genre" => "Classic", "book_picture" => "images/to_kill_a_mockingbird.jpg"],
    ["title" => "1984", "author" => "George Orwell", "price" => 9.99, "genre" => "Dystopian", "book_picture" => "images/1984.jpg"],
    ["title" => "The Great Gatsby", "author" => "F. Scott Fitzgerald", "price" => 7.99, "genre" => "Classic", "book_picture" => "images/great_gatsby.jpg"],
    ["title" => "The Catcher in the Rye", "author" => "J.D. Salinger", "price" => 7.49, "genre" => "Coming-of-age", "book_picture" => "images/catcher_in_the_rye.jpg"],
    ["title" => "The Lord of the Rings", "author" => "J.R.R. Tolkien", "price" => 14.99, "genre" => "Fantasy", "book_picture" => "images/lord_of_the_rings.jpg"],
    ["title" => "Pride and Prejudice", "author" => "Jane Austen", "price" => 6.99, "genre" => "Romance", "book_picture" => "images/pride_and_prejudice.jpg"],
    ["title" => "The Hitchhiker's Guide to the Galaxy", "author" => "Douglas Adams", "price" => 7.99, "genre" => "Science Fiction", "book_picture" => "images/hitchhikers_guide.jpg"],
    ["title" => "Fahrenheit 451", "author" => "Ray Bradbury", "price" => 8.99, "genre" => "Dystopian", "book_picture" => "images/fahrenheit_451.jpg"],
    ["title" => "Brave New World", "author" => "Aldous Huxley", "price" => 9.99, "genre" => "Dystopian", "book_picture" => "images/brave_new_world.jpg"],
    ["title" => "The Chronicles of Narnia", "author" => "C.S. Lewis", "price" => 10.99, "genre" => "Fantasy", "book_picture" => "images/chronicles_of_narnia.jpg"],
    ["title" => "The Book Thief", "author" => "Markus Zusak", "price" => 9.49, "genre" => "Historical Fiction", "book_picture" => "images/book_thief.jpg"],
    ["title" => "Moby Dick", "author" => "Herman Melville", "price" => 10.49, "genre" => "Adventure", "book_picture" => "images/moby_dick.jpg"],
    ["title" => "Catch-22", "author" => "Joseph Heller", "price" => 8.49, "genre" => "Satire", "book_picture" => "images/catch_22.jpg"],
    ["title" => "The Picture of Dorian Gray", "author" => "Oscar Wilde", "price" => 6.49, "genre" => "Gothic Fiction", "book_picture" => "images/picture_of_dorian_gray.jpg"],
    ["title" => "Jane Eyre", "author" => "Charlotte Brontë", "price" => 7.99, "genre" => "Romance", "book_picture" => "images/jane_eyre.jpg"],
    ["title" => "The Alchemist", "author" => "Paulo Coelho", "price" => 8.99, "genre" => "Philosophical Fiction", "book_picture" => "images/alchemist.jpg"],
    ["title" => "War and Peace", "author" => "Leo Tolstoy", "price" => 11.99, "genre" => "Historical Fiction", "book_picture" => "images/war_and_peace.jpg"],
    ["title" => "Hamlet", "author" => "William Shakespeare", "price" => 6.99, "genre" => "Tragedy", "book_picture" => "images/hamlet.jpg"],
    ["title" => "The Odyssey", "author" => "Homer", "price" => 10.99, "genre" => "Epic Poetry", "book_picture" => "images/odyssey.jpg"],
    ["title" => "Crime and Punishment", "author" => "Fyodor Dostoevsky", "price" => 10.49, "genre" => "Psychological Fiction", "book_picture" => "images/crime_and_punishment.jpg"],
    ["title" => "Wuthering Heights", "author" => "Emily Brontë", "price" => 8.49, "genre" => "Gothic Fiction", "book_picture" => "images/wuthering_heights.jpg"],
    ["title" => "The Grapes of Wrath", "author" => "John Steinbeck", "price" => 9.49, "genre" => "Historical Fiction", "book_picture" => "images/grapes_of_wrath.jpg"],
    ["title" => "Little Women", "author" => "Louisa May Alcott", "price" => 7.49, "genre" => "Coming-of-age", "book_picture" => "images/little_women.jpg"],
    ["title" => "The Kite Runner", "author" => "Khaled Hosseini", "price" => 9.99, "genre" => "Historical Fiction", "book_picture" => "images/kite_runner.jpg"],
    ["title" => "The Road", "author" => "Cormac McCarthy", "price" => 8.99, "genre" => "Post-apocalyptic Fiction", "book_picture" => "images/road.jpg"],
    ["title" => "A Tale of Two Cities", "author" => "Charles Dickens", "price" => 7.99, "genre" => "Historical Fiction", "book_picture" => "images/tale_of_two_cities.jpg"],
    ["title" => "The Diary of a Young Girl", "author" => "Anne Frank", "price" => 6.99, "genre" => "Memoir", "book_picture" => "images/diary_of_a_young_girl.jpg"],
    ["title" => "The Brothers Karamazov", "author" => "Fyodor Dostoevsky", "price" => 11.49, "genre" => "Philosophical Fiction", "book_picture" => "images/brothers_karamazov.jpg"],
    ["title" => "The Fault in Our Stars", "author" => "John Green", "price" => 8.49, "genre" => "Young Adult", "book_picture" => "images/fault_in_our_stars.jpg"],
    ["title" => "The Secret Garden", "author" => "Frances Hodgson Burnett", "price" => 6.49, "genre" => "Children's Fiction", "book_picture" => "images/secret_garden.jpg"]
];


// Insert books into the database
foreach ($defaultBooks as $book) {
    $stmt = $conn->prepare("INSERT INTO Books (title, author, price, genre, book_picture) 
                            VALUES (?, ?, ?, ?, ?) 
                            ON DUPLICATE KEY UPDATE 
                            price = VALUES(price), genre = VALUES(genre), book_picture = VALUES(book_picture)");
    $stmt->bind_param("ssdss", $book['title'], $book['author'], $book['price'], $book['genre'], $book['book_picture']);
    $stmt->execute();
}

// Close connection
$conn->close();
?>
