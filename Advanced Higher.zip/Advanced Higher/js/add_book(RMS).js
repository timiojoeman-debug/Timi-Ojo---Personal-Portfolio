document.getElementById("bookForm").addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent form refresh

    const title = document.getElementById("title").value;
    const author = document.getElementById("author").value;
    const genre = document.getElementById("genre").value;
    const bookPrice = parseFloat(document.getElementById("bookPrice").value);
    const imageInput = document.getElementById("imageUpload");
    const imageFile = imageInput.files[0];

    if (!imageFile) {
        alert("Please upload an image.");
        return;
    }

    const reader = new FileReader();
    reader.readAsDataURL(imageFile);
    reader.onload = function () {
        const imageBase64 = reader.result;

        const newBook = { title, author, genre, bookPrice, image: imageBase64 };

        let books = JSON.parse(localStorage.getItem("books")) || [];
        books.push(newBook);
        localStorage.setItem("books", JSON.stringify(books));

        alert("Book added successfully!");
        window.location.href = "index2.php"; // Redirect back to home
    };
});

// Show image preview
document.getElementById("imageUpload").addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = function () {
            const previewImage = document.getElementById("previewImage");
            previewImage.src = reader.result;
            previewImage.style.display = "block";
        };
    }
});
