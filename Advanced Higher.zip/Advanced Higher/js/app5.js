console.log("app5.js is loaded");
document.addEventListener("DOMContentLoaded", function () {
    initBooks();
    detectPage();
    updateCartCount();
});

// Default books
const defaultBooks = [
    { title: 'To Kill a Mockingbird', image: 'images/to_kill_a_mockingbird.jpg', author: 'Harper Lee', bookPrice: 8.49, genre: 'Classic' },
    { title: '1984', image: 'images/1984.jpg', author: 'George Orwell', bookPrice: 9.99, genre: 'Dystopian' },
    { title: 'The Great Gatsby', image: 'images/great_gatsby.jpg', author: 'F. Scott Fitzgerald', bookPrice: 7.99, genre: 'Classic' },
    { title: 'The Catcher in the Rye', image: 'images/catcher_in_the_rye.jpg', author: 'J.D. Salinger', bookPrice: 7.49, genre: 'Coming-of-age' },
    { title: 'The Lord of the Rings', image: 'images/lord_of_the_rings.jpg', author: 'J.R.R. Tolkien', bookPrice: 14.99, genre: 'Fantasy' },
    { title: 'Pride and Prejudice', image: 'images/pride_and_prejudice.jpg', author: 'Jane Austen', bookPrice: 6.99, genre: 'Romance' },
    { title: 'The Hitchhiker\'s Guide to the Galaxy', image: 'images/hitchhikers_guide.jpg', author: 'Douglas Adams', bookPrice: 7.99, genre: 'Science Fiction' },
    { title: 'Fahrenheit 451', image: 'images/fahrenheit_451.jpg', author: 'Ray Bradbury', bookPrice: 8.99, genre: 'Dystopian' },
    { title: 'Brave New World', image: 'images/brave_new_world.jpg', author: 'Aldous Huxley', bookPrice: 9.99, genre: 'Dystopian' },
    { title: 'The Chronicles of Narnia', image: 'images/chronicles_of_narnia.jpg', author: 'C.S. Lewis', bookPrice: 10.99, genre: 'Fantasy' },
    { title: 'The Book Thief', image: 'images/book_thief.jpg', author: 'Markus Zusak', bookPrice: 9.49, genre: 'Historical Fiction' },
    { title: 'Moby Dick', image: 'images/moby_dick.jpg', author: 'Herman Melville', bookPrice: 10.49, genre: 'Adventure' },
    { title: 'Catch-22', image: 'images/catch_22.jpg', author: 'Joseph Heller', bookPrice: 8.49, genre: 'Satire' },
    { title: 'The Picture of Dorian Gray', image: 'images/picture_of_dorian_gray.jpg', author: 'Oscar Wilde', bookPrice: 6.49, genre: 'Gothic Fiction' },
    { title: 'Jane Eyre', image: 'images/jane_eyre.jpg', author: 'Charlotte Brontë', bookPrice: 7.99, genre: 'Romance' },
    { title: 'The Alchemist', image: 'images/alchemist.jpg', author: 'Paulo Coelho', bookPrice: 8.99, genre: 'Philosophical Fiction' },
    { title: 'War and Peace', image: 'images/war_and_peace.jpg', author: 'Leo Tolstoy', bookPrice: 11.99, genre: 'Historical Fiction' },
    { title: 'Hamlet', image: 'images/hamlet.jpg', author: 'William Shakespeare', bookPrice: 6.99, genre: 'Tragedy' },
    { title: 'The Odyssey', image: 'images/odyssey.jpg', author: 'Homer', bookPrice: 10.99, genre: 'Epic Poetry' },
    { title: 'Crime and Punishment', image: 'images/crime_and_punishment.jpg', author: 'Fyodor Dostoevsky', bookPrice: 10.49, genre: 'Psychological Fiction' },
    { title: 'Wuthering Heights', image: 'images/wuthering_heights.jpg', author: 'Emily Brontë', bookPrice: 8.49, genre: 'Gothic Fiction' },
    { title: 'The Grapes of Wrath', image: 'images/grapes_of_wrath.jpg', author: 'John Steinbeck', bookPrice: 9.49, genre: 'Historical Fiction' },
    { title: 'Little Women', image: 'images/little_women.jpg', author: 'Louisa May Alcott', bookPrice: 7.49, genre: 'Coming-of-age' },
    { title: 'The Kite Runner', image: 'images/kite_runner.jpg', author: 'Khaled Hosseini', bookPrice: 9.99, genre: 'Historical Fiction' },
    { title: 'The Road', image: 'images/road.jpg', author: 'Cormac McCarthy', bookPrice: 8.99, genre: 'Post-apocalyptic Fiction' },
    { title: 'A Tale of Two Cities', image: 'images/tale_of_two_cities.jpg', author: 'Charles Dickens', bookPrice: 7.99, genre: 'Historical Fiction' },
    { title: 'The Diary of a Young Girl', image: 'images/diary_of_a_young_girl.jpg', author: 'Anne Frank', bookPrice: 6.99, genre: 'Memoir' },
    { title: 'The Brothers Karamazov', image: 'images/brothers_karamazov.jpg', author: 'Fyodor Dostoevsky', bookPrice: 11.49, genre: 'Philosophical Fiction' },
    { title: 'The Fault in Our Stars', image: 'images/fault_in_our_stars.jpg', author: 'John Green', bookPrice: 8.49, genre: 'Young Adult' },
    { title: 'The Secret Garden', image: 'images/secret_garden.jpg', author: 'Frances Hodgson Burnett', bookPrice: 6.49, genre: 'Children\'s Fiction' }
];

// Initialize books in localStorage
function initBooks() {
    if (!localStorage.getItem("books")) {
        localStorage.setItem("books", JSON.stringify(defaultBooks));
    }
    if (!localStorage.getItem("cart")) {
        localStorage.setItem("cart", JSON.stringify([]));
    }
}

// Detect page and call the appropriate function
function detectPage() {
    const currentPage = window.location.href;

    if (currentPage.includes('index2.html') || currentPage.includes('index2.php')) {
        renderBookItems();
    } else if (currentPage.includes('cart2.html') || currentPage.includes('cart2.php')) {
        renderCartItems();
    }

    calculateTotal();
}

// Render books on store page
function renderBookItems() {
    const bookContainer = document.getElementById("bookContainer");
    if (!bookContainer) return;

    bookContainer.innerHTML = "";
    const books = JSON.parse(localStorage.getItem("books")) || [];

    books.forEach(book => {
        const bookItem = document.createElement("div");
        bookItem.classList.add("book-item");

        bookItem.innerHTML = `
            <img src="${book.image}" alt="${book.title}">
            <h3>${book.title}</h3>
            <p><strong>Author:</strong> ${book.author}</p>
            <p><strong>Genre:</strong> ${book.genre}</p>
            <p><strong>Price:</strong> £${book.bookPrice.toFixed(2)}</p>
            <button class="add-to-cart" data-title="${book.title}" data-price="${book.bookPrice}" data-image="${book.image}">Add to Cart</button>
        `;

        bookContainer.appendChild(bookItem);
    });

    document.querySelectorAll(".add-to-cart").forEach(button => {
        button.addEventListener("click", addToCart);
    });
}

// Add book to cart
function addToCart(event) {
    const title = event.target.dataset.title;
    const price = parseFloat(event.target.dataset.price);
    const image = event.target.dataset.image;

    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    const existingItem = cart.find(item => item.title === title);

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ title, price, image, quantity: 1 });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`${title} added to cart!`);
    updateCartCount();
}

// Render cart items
function renderCartItems() {
    const cartList = document.getElementById('cart-items');
    if (!cartList) return;

    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cartList.innerHTML = '';

    cart.forEach(item => {
        const cartRow = document.createElement('tr');

        cartRow.innerHTML = `
            <td>
                <div class="cart-item">
                    <img src="${item.image}" alt="${item.title}">
                    <span>${item.title}</span>
                </div>
            </td>
            <td>£${item.price.toFixed(2)}</td>
            <td>
                <input type="number" min="1" value="${item.quantity}" class="quantity-input" data-title="${item.title}">
            </td>
            <td>£${(item.price * item.quantity).toFixed(2)}</td>
            <td>
                <button class="remove-button" data-title="${item.title}">Remove</button>
            </td>
        `;

        cartList.appendChild(cartRow);
    });

    calculateTotal();

    document.querySelectorAll('.remove-button').forEach(button => {
        button.addEventListener('click', removeFromCart);
    });

    document.querySelectorAll('.quantity-input').forEach(input => {
        input.addEventListener('change', updateQuantity);
    });
}

// Remove item from cart
function removeFromCart(event) {
    const title = event.target.dataset.title;
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    cart = cart.filter(item => item.title !== title);
    localStorage.setItem('cart', JSON.stringify(cart));

    renderCartItems();
}

// Update quantity in cart
function updateQuantity(event) {
    const title = event.target.dataset.title;
    const quantity = parseInt(event.target.value);

    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    const item = cart.find(item => item.title === title);

    if (item && quantity > 0) {
        item.quantity = quantity;
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    renderCartItems();
    calculateTotal();
}

// 🔹 Update cart count badge
function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartCount = cart.reduce((total, item) => total + (item.quantity || 1), 0);
    const cartCountElement = document.getElementById('cart-count');

    if (cartCountElement) {
        cartCountElement.textContent = cartCount;
    }
}

// Calculate total price
function calculateTotal() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    let total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

    const totalAmountElement = document.getElementById('totalAmount');
    if (totalAmountElement) {
        totalAmountElement.textContent = `£${total.toFixed(2)}`;
    }
}



//-----------------------------------------------
// Checkout button
// Assuming this is part of your app5.js or another included script
// Function to handle checkout
document.addEventListener("DOMContentLoaded", function () {
    initBooks();
    detectPage();
    updateCartCount();

    // Add an event listener to the checkout button
    const checkoutButton = document.getElementById('checkout-btn');
    console.log(checkoutButton); // This should log the button element or null

    if (checkoutButton) {
        checkoutButton.addEventListener('click', function() {
            const cartItems = document.querySelectorAll('#cart-items tr');
        
            if (cartItems.length === 0) {
                alert("Your cart is empty. Please add items before checking out.");
                return;
            }
        
            const totalAmount = document.getElementById('totalAmount').textContent;
            const totalPrice = parseFloat(totalAmount.replace('£', '').replace(',', ''));
        
            const cart = JSON.parse(localStorage.getItem('cart')) || [];
        
            const data = {
                cart: cart,
                totalPrice: totalPrice
            };
        
            fetch('checkout.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data) // Pass the necessary data to the backend (e.g., cart details)
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'error') {
                    // If the server returns an error, handle it here
                    if (data.message === 'User is not logged in') {
                        // Alert the user and redirect them to the login page
                        alert('You must be logged in to place an order.');
                        window.location.href = 'login+register.html'; // Redirect to login page
                    } else {
                        alert(data.message); // Handle other errors
                    }
                } else if (data.status === 'success') {
                    // Handle successful order placement
                    alert('Order placed successfully!');
                    // Optionally, clear the cart and update the UI
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('There was an error processing the order. Please try again later.');
            });            
        });
    } else {
        console.error('Checkout button not found!');
    }
});