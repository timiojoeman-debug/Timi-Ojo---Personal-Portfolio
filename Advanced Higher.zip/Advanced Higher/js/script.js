// Select necessary elements
const wrapper = document.querySelector('.wrapper')
const registerLink = document.querySelector('.register-link') // Register to login
const loginLink = document.querySelector('.login-link') // Login to register

// Add event listeners for toggling the 'active' class
registerLink.onclick = () => {
    wrapper.classList.add('active')
}

loginLink.onclick = () => {
    wrapper.classList.remove('active')
}