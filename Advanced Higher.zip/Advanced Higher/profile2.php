<?php
session_start(); // Start the session

if (!is_dir('uploads')) {
    mkdir('uploads', 0777, true);
}


// Check if the user is logged in
if (isset($_SESSION['user_id']) && isset($_SESSION['username']) && isset($_SESSION['created_at'])) {
    $user_id = $_SESSION['user_id'];
    $username = $_SESSION['username'];
    $created_at = $_SESSION['created_at']; 
} else {
    header("Location: login+register.html");
    exit();
}

// Database connection details
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "bookstore";
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle file upload (if needed)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['profile_picture'])) {
        $fileError = $_FILES['profile_picture']['error'];
        $uploadOk = true; // Initialize the variable

        if ($fileError === UPLOAD_ERR_OK) {
            $targetDir = __DIR__ . "/uploads/";
            $fileTmpPath = $_FILES['profile_picture']['tmp_name'];
            $fileName = basename($_FILES["profile_picture"]["name"]);
            $targetFile = $targetDir . $fileName;

            // Check if the file is a valid image
            $check = getimagesize($fileTmpPath);
            if ($check === false) {
                echo "File is not an image.";
                $uploadOk = false; // Update upload status
            }

            // Check file size (allow files up to 500KB)
            if ($_FILES["profile_picture"]["size"] > 500000) {
                echo "Sorry, your file is too large.";
                $uploadOk = false; // Update upload status
            }

            // Allow certain file formats
            $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
            if (!in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
                echo "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
                $uploadOk = false; // Update upload status
            }

            // Proceed with upload if no errors
            if ($uploadOk) {
                if (move_uploaded_file($fileTmpPath, $targetFile)) {
                    // Update the profile picture in the database with just the filename
                    $stmt = $conn->prepare("UPDATE Users SET profile_picture = ? WHERE user_id = ?");
                    $stmt->bind_param("si", $fileName, $user_id);
                    if ($stmt->execute()) {
                        echo "<script>alert(`Profile picture updated successfully.`);</script>";
                    } else {
                        echo "<script>alert(`Error updating profile picture.`);</script>";
                    }
                    $stmt->close();
                } else {
                    echo "<script>alert(`Sorry, there was an error uploading your file.`);</script>";
                }
            }
        } else {
            // Handle file upload errors
            switch ($fileError) {
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    echo "Uploaded file exceeds the allowed size.";
                    break;
                case UPLOAD_ERR_PARTIAL:
                    echo "File was only partially uploaded.";
                    break;
                case UPLOAD_ERR_NO_FILE:
                    echo "No file was uploaded.";
                    break;
                case UPLOAD_ERR_NO_TMP_DIR:
                    echo "Missing a temporary folder.";
                    break;
                case UPLOAD_ERR_CANT_WRITE:
                    echo "Failed to write file to disk.";
                    break;
                case UPLOAD_ERR_EXTENSION:
                    echo "File upload stopped by a PHP extension.";
                    break;
                default:
                    echo "Unknown upload error.";
                    break;
            }
        }
    } else {
        echo "No file input was found.";
    }
} //else {
    //echo "Not a POST request.";
//}

// Fetch the user's profile picture (after potential update)
$stmt = $conn->prepare("SELECT profile_picture FROM Users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($profilePicture);
$stmt->fetch();
$stmt->close();
$conn->close();

// Default profile picture logic
if (empty($profilePicture)) {
    $profilePicture = "default-avatar.jpg"; // Make sure this file exists in your uploads directory or in the same directory
}

// Construct the full URL for the profile picture
$relativePath = "uploads/" . $profilePicture; // Update the relative path with the latest picture or default
$baseUrl = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/';
$profilePictureUrl = $baseUrl . htmlspecialchars($relativePath); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
        }
        .card {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        /*.profile-pic {
            position: relative;
            width: 150px;
            height: 150px;
            margin: 20px auto;
            border-radius: 50%;
            overflow: hidden;
            border: 4px solid #8E24AA;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #e0e0e0;
        }
        .profile-pic img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }*/

        .profile-pic {
            position: relative;
            width: 150px; /* Adjust the size as needed */
            height: 150px; /* Adjust the size as needed */
            margin: 20px auto;
            border-radius: 50%;
            overflow: hidden;
            border: 4px solid rgb(39, 37, 40); /* Border color */
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #e0e0e0; /* Fallback background */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
            transition: transform 0.3s; /* Smooth hover effect */
        }

        .profile-pic:hover {
            transform: scale(1.05); /* Slightly enlarge on hover */
        }

        .profile-pic img {
            width: 100%; /* Ensure the image covers the container */
            height: 100%; /* Ensure the image covers the container */
            object-fit: cover; /* Maintain aspect ratio and cover the area */
            border-radius: 50%; /* Round the image edges */
            transition: opacity 0.3s; /* Smooth fade effect */
        }

        .upload-btn {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background: rgb(39, 37, 40); /* Button background color */
            color: white; /* Button text color */
            border: none; /* Remove default border */
            padding: 8px 12px; /* Add padding */
            border-radius: 20px; /* Round buttons for better look */
            cursor: pointer; /* Change cursor to pointer on hover */
            transition: background 0.3s, transform 0.3s; /* Smooth transition effects */
        }

        /* More button states for better user experience */
        button[type="button"]:hover {
            background: rgb(39, 37, 40); /* Darker shade on hover */
            transform: scale(1.05); /* Slightly enlarge on hover */
        }

        button[type="submit"]:hover {
            transform: scale(1.05);
        }

        button[type="button"] {
            background: rgb(39, 37, 40); /* Submit button color */
            color: white; /* Submit button text color */
            border: none; /* Remove default borders */
            padding: 8px 12px; /* Add padding */
            border-radius: 20px; /* Round edges */
            margin-top: 10px; /* Space above the button */
            cursor: pointer; /* Change cursor on hover */
        }

        button[type="submit"] {
            background: rgb(217, 222, 217); /* Submit button color */
            color: black; /* Submit button text color */
            border: none; /* Remove default borders */
            padding: 8px 12px; /* Add padding */
            border-radius: 20px; /* Round edges */
            margin-top: 10px; /* Space above the button */
            cursor: pointer; /* Change cursor on hover */
        }

        button[type="submit"]:hover {
            background:rgb(217, 222, 217); /* Darker green on hover */
        }

        .upload-btn {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background:rgb(39, 37, 40);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 20px;
            cursor: pointer;
        }

        /*-----------------------------------------------------------*/
        /* From Uiverse.io by namecho */ 
        button,
        button::after {
            padding: 16px 20px;
            font-size: 18px;
            background: linear-gradient(45deg, transparent 5%, #ff013c 5%);
            border: 0;
            color: #fff;
            letter-spacing: 3px;
            line-height: 1;
            box-shadow: 6px 0px 0px #00e6f6;
            outline: transparent;
            position: relative;
        }

        button::after {
            --slice-0: inset(50% 50% 50% 50%);
            --slice-1: inset(80% -6px 0 0);
            --slice-2: inset(50% -6px 30% 0);
            --slice-3: inset(10% -6px 85% 0);
            --slice-4: inset(40% -6px 43% 0);
            --slice-5: inset(80% -6px 5% 0);
            content: "TIMI";
            display: block;
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 3%, #00e6f6 3%, #00e6f6 5%, #ff013c 5%);
            text-shadow: -3px -3px 0px #f8f005, 3px 3px 0px #00e6f6;
            clip-path: var(--slice-0);
        }

        button:hover::after {
            animation: 1s glitch;
            animation-timing-function: steps(2, end);
        }

        @keyframes glitch {
            0% { clip-path: var(--slice-1); transform: translate(-20px, -10px); }
            10% { clip-path: var(--slice-3); transform: translate(10px, 10px); }
            20% { clip-path: var(--slice-1); transform: translate(-10px, 10px); }
            30% { clip-path: var(--slice-3); transform: translate(0px, 5px); }
            40% { clip-path: var(--slice-2); transform: translate(-5px, 0px); }
            50% { clip-path: var(--slice-3); transform: translate(5px, 0px); }
            60% { clip-path: var(--slice-4); transform: translate(5px, 10px); }
            70% { clip-path: var(--slice-2); transform: translate(-10px, 10px); }
            80% { clip-path: var(--slice-5); transform: translate(20px, -10px); }
            90% { clip-path: var(--slice-1); transform: translate(-10px, 0px); }
            100% { clip-path: var(--slice-1); transform: translate(0); }
        }
    </style>
</head>
<body>

<div class="card">
    <div class="text-center">
        <div class="profile-pic">
            <img src="<?php echo $profilePictureUrl; ?>" alt="Profile Picture" id="profileImg">
        </div>
        <form id="uploadForm" enctype="multipart/form-data" method="POST">
            <input type="file" name="profile_picture" accept="image/*" id="fileInput" style="display: none;">
            <button type="button" onclick="document.getElementById('fileInput').click()">Change</button>
            <button type="submit">Upload</button>
        </form>
        
        <script>
            const fileInput = document.getElementById('fileInput');
            const profileImg = document.getElementById('profileImg');

            fileInput.addEventListener('change', function () {
                if (fileInput.files && fileInput.files[0]) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        profileImg.src = e.target.result; // Set the image source dynamically
                    };
                    reader.readAsDataURL(fileInput.files[0]);
                }
            });
        </script>
    </div>
    <div class="text-center mt-4">
        <h4 id="username"><?php echo htmlspecialchars($username); ?></h4>
    </div>
    <div class="mt-4">
        <h5>Basic Info</h5>
        <table class="table">
            <tr>
                <td>User ID:</td>
                <td id="userId"><?php echo htmlspecialchars($user_id); ?></td>
            </tr>
            <tr>
                <td>Joined:</td>
                <td id="joined"><?php echo htmlspecialchars($created_at); ?></td>
            </tr>
            <tr>
                <td>Status:</td>
                <td><span class='prof-status'>active</span></td>
            </tr>
        </table>
    </div>
</div>

</body>
</html>