CREATE DATABASE bookstore;

USE bookstore;

CREATE TABLE Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    profile_picture VARCHAR(255) DEFAULT 'uploads/default-avatar.jpg',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE Books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL, -- Adjusted for higher value range if needed
    genre VARCHAR(50) NOT NULL,
    book_picture VARCHAR(255) NOT NULL DEFAULT 'uploads/book-avatar.png',
    UNIQUE (title, author),
    CONSTRAINT chk_genre CHECK (genre IN (
        'Classic', 'Dystopian', 'Coming-of-age', 'Fantasy', 'Romance', 
        'Science Fiction', 'Historical Fiction', 'Adventure', 'Satire', 
        'Gothic Fiction', 'Philosophical Fiction', 'Tragedy', 'Epic Poetry', 
        'Psychological Fiction', 'Post-apocalyptic Fiction', 'Memoir', 
        'Young Adult', "Children's Fiction", 'Psychological Non-Fiction', 'Non-Fiction'
    ))
);


CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);


CREATE TABLE order_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    book_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES Books(book_id) ON DELETE CASCADE
);


