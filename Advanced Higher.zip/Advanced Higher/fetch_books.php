<?php
// Connect to database and fetch books
$result = $db->query("SELECT * FROM books");
while($book = $result->fetch_assoc()) {
    echo '<div class="book-item">';
    echo '<img src="images/' . $book['image'] . '" alt="' . $book['title'] . '">';
    echo '<h3>' . $book['title'] . '</h3>';
    echo '<p>Author: ' . $book['author'] . '</p>';
    echo '<p>Price: £' . $book['price'] . '</p>';
    echo '<button onclick="addToCart(' . $book['id'] . ')">Add to Cart</button>';
    echo '</div>';
}
?>
