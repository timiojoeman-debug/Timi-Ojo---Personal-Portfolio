<?php
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];

if (!empty($username) && !empty($email) && !empty($password)) {
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "bookstore";

    // Create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

    if (mysqli_connect_error()) {
        die('Connect Error('. mysqli_connect_errno() . ') ' . mysqli_connect_error());
    } else {
        $SELECT = "SELECT email FROM Users WHERE email = ? LIMIT 1";
        $INSERT = "INSERT INTO Users (username, email, password) VALUES(?, ?, ?)";

        // Prepare statement
        $stmt = $conn->prepare($SELECT);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        $rnum = $stmt->num_rows;

        if ($rnum == 0) {
            $stmt->close();

            // Hash the password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insert user into the database
            $stmt = $conn->prepare($INSERT);
            $stmt->bind_param("sss", $username, $email, $hashedPassword);
            $stmt->execute();
            echo "Registration successful!";
        } else {
            echo "This email is already registered.";
        }
        $stmt->close();
        $conn->close();
    }
} else {
    echo "All fields are required.";
    die();
}
?>
