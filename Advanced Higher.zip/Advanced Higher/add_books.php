<?php
header('Content-Type: application/json'); // Ensure JSON response

$servername = "localhost";
$username = "root"; // Change this if necessary
$password = ""; // Change this if necessary
$dbname = "bookstore"; // Your database name

// Connect to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit();
}

// Allowed genres based on database constraint
$allowedGenres = [
    'Classic', 'Dystopian', 'Coming-of-age', 'Fantasy', 'Romance',
    'Science Fiction', 'Historical Fiction', 'Adventure', 'Satire',
    'Gothic Fiction', 'Philosophical Fiction', 'Tragedy', 'Epic Poetry',
    'Psychological Fiction', 'Post-apocalyptic Fiction', 'Memoir',
    'Young Adult', "Children's Fiction", 'Psychological Non-Fiction', 'Non-Fiction'
];

// Check if form fields are set
if (!isset($_POST['title'], $_POST['author'], $_POST['genre'], $_POST['bookPrice'])) {
    echo json_encode(["success" => false, "message" => "Missing required fields"]);
    exit();
}

// Retrieve form data
$title = $conn->real_escape_string($_POST['title']);
$author = $conn->real_escape_string($_POST['author']);
$genre = $conn->real_escape_string($_POST['genre']);
$bookPrice = floatval($_POST['bookPrice']);
$imagePath = null;

// Validate genre
if (!in_array($genre, $allowedGenres)) {
    echo json_encode(["success" => false, "message" => "Invalid genre selected."]);
    exit();
}

// Handle image upload if provided
if (isset($_FILES['imageUpload']) && $_FILES['imageUpload']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = "images/"; // Ensure this folder exists
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true); // Create directory if it doesn't exist
    }

    $imageFileType = strtolower(pathinfo($_FILES["imageUpload"]["name"], PATHINFO_EXTENSION));
    $allowedTypes = ["jpg", "jpeg", "png", "gif"];

    if (!in_array($imageFileType, $allowedTypes)) {
        echo json_encode(["success" => false, "message" => "Invalid image format. Only JPG, PNG, and GIF allowed."]);
        exit();
    }

    // Save image with a unique name
    $imagePath = $uploadDir . time() . "_" . basename($_FILES["imageUpload"]["name"]);
    
    if (!move_uploaded_file($_FILES["imageUpload"]["tmp_name"], $imagePath)) {
        echo json_encode(["success" => false, "message" => "Failed to upload image"]);
        exit();
    }
}

// Insert data into the database
$sql = "INSERT INTO books (title, author, genre, price, book_picture) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssds", $title, $author, $genre, $bookPrice, $imagePath);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Book added successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Error adding book: " . $stmt->error]);
}

// Close connections
$stmt->close();
$conn->close();
?>
