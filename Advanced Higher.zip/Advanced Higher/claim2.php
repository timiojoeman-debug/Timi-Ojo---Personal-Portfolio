<?php
session_start();

// Retrieve POST parameters safely
$username = $_POST['username'] ?? ''; // Use null coalescing operator
$password = $_POST['password'] ?? '';

// Database connection details
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "bookstore";

// Create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare SQL statement to select user data
$SELECT = "SELECT user_id, password, created_at FROM Users WHERE username = ?";
$stmt = $conn->prepare($SELECT);
if ($stmt === false) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
}

// Bind parameters and execute the query
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->store_result();

// Check if user exists
if ($stmt->num_rows > 0) {
    $stmt->bind_result($user_id, $storedPassword, $created_at);
    $stmt->fetch();
    
    // Verify password
    if (password_verify($password, $storedPassword)) {
        // Store user data in the session
        $_SESSION['user_id'] = $user_id;
        $_SESSION['username'] = $username;
        $_SESSION['created_at'] = $created_at; // Store creation timestamp in the session
        
        // Redirect to another page
        header("Location: index2.php");
        exit();
    } else {
        echo "Invalid password.";
    }
} else {
    echo "No account found with the provided username.";
}

// Close statement and connection
$stmt->close();
$conn->close();
?>