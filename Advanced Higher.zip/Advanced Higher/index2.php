<?php
include_once "insert_books.php";
session_start(); // Start the session

// Database connection details
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "bookstore";

// Create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Default profile picture
$profilePicture = "default-avatar.jpg"; // Default if not logged in

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Fetch the user's profile picture 
    $stmt = $conn->prepare("SELECT profile_picture FROM Users WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($profilePicture);
    $stmt->fetch();
    $stmt->close();
    
    // Check if profile picture is empty
    if (empty($profilePicture)) {
        $profilePicture = "default-avatar.jpg"; // Default if no picture is set
    }
} 

// Construct the full URL for the profile picture
$relativePath = "uploads/" . $profilePicture; // Update the relative path
$baseUrl = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/';
$profilePictureUrl = htmlspecialchars($baseUrl . $relativePath); 

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Online Bookstore</title>
    <style>
        .cart-badge {
            background-color: red;
            color: white;
            font-size: 0.75rem; /* Use relative units for font size */
            font-weight: bold;
            border-radius: 50%; /* Ensures a circular shape */
            width: 1.5em; /* Set explicit width */
            height: 1.5em; /* Set explicit height */
            position: absolute;
            top: 33%; /* Adjust to your design */
            right: 5%; /* Adjust to your design */
            display: flex; /* Use flexbox for centering content */
            align-items: center; /* Center content vertically */
            justify-content: center; /* Center content horizontally */
            line-height: 1; /* Prevent extra height due to line spacing */
            text-align: center;
            transform: translate(50%, -50%); /* Fine-tune positioning */
            box-sizing: border-box; /* Ensures padding and borders don’t affect the width/height */
        }
        
        
        @media (max-width: 960px) {
            .cart-badge {
                font-size: 0.6rem;
                width: 1.2em; 
                height: 1.2em;
                top: 33%;
                left: 55.5%;
                align-items: center;
                justify-content: center;
                border-radius: 50%; /*to create a circular shape. */
            }
        }
    </style>

    <style>
        /* Base Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #ffffff;
            color: #000000;
            margin: 0;
            padding: 0;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        /* Dark Mode Styles */
        body.dark-mode {
            background-color: #121212;
            color: #ffffff;
        }

        #darkModeToggle {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px; /* Space between text and icon */
            transition: background-color 0.3s ease, color 0.3s ease;
            margin: 20px;
        }

        /* Button Hover */
        #darkModeToggle:hover {
            background-color: #555;
        }

        /* Icon */
        #darkModeToggle i {
            font-size: 18px;
            transition: transform 0.3s ease;
        }

        /* Optional Spin Animation */
        #darkModeToggle i:active {
            transform: rotate(360deg);
        }

        /* Button in Dark Mode */
        body.dark-mode #darkModeToggle {
            background-color: #ddd;
            color: #000;
        }

        body.dark-mode #darkModeToggle:hover {
            background-color: #bbb;
        }

        #genreFilter {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px; /* Space between text and icon */
            transition: background-color 0.3s ease, color 0.3s ease;
            margin: 20px;
        }

        body.dark-mode #genreFilter {
            background-color: #ddd;
            color: #000;
        }

        body.dark-mode #genreFilter:hover {
            background-color: #bbb;
        }

        .Btn {
            display: flex;
            align-items: center;
            justify-content: flex-start;
            width: 45px;
            height: 45px;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition-duration: .3s;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.199);
            background-color: rgb(255, 65, 65);
        }

        /* plus sign */
        .sign {
            width: 100%;
            transition-duration: .3s;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .sign svg {
            width: 17px;
        }

        .sign svg path {
            fill: white;
        }

        /* text */
        .text {
            position: absolute;
            right: 0%;
            width: 0%;
            opacity: 0;
            color: white;
            font-size: 1.2em;
            font-weight: 600;
            transition-duration: .3s;
        }

        /* hover effect on button width */
        .Btn:hover {
            width: 125px;
            border-radius: 40px;
            transition-duration: .3s;
        }

        .Btn:hover .sign {
            width: 30%;
            transition-duration: .3s;
            padding-left: 20px;
        }

        /* hover effect button's text */
        .Btn:hover .text {
            opacity: 1;
            width: 70%;
            transition-duration: .3s;
            padding-right: 10px;
        }
        /* button click effect*/
        .Btn:active {
            transform: translate(2px ,2px);
        }

        #profileImg {
        width: 40px; /* Set the width to match the navbar icon size */
        height: 40px; /* Set the height to match the navbar icon size */
        border-radius: 50%; /* Add a rounded corner effect */
        object-fit: cover; /* Ensure the image is displayed without stretching */
        cursor: pointer; /* Change the cursor to a pointer when hovered */
        }

        .navbar__link:hover {
            color: #00e6f6; /* Existing color change on hover */
        }

        /* Hover Circle Effect */
        .navbar__link::after {
            content: '';
            position: absolute;
            top: 50%; /* Center vertically */
            left: 50%; /* Center horizontally */
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            border: 2px solid #00e6f6; /* Circle border color */
            border-radius: 50%; /* Makes the border circular */
            transform: translate(-50%, -50%) scale(0); /* Start scaled down to 0 at the center */
            transition: transform 0.3s ease; /* Smooth scale transition */
            z-index: -1; /* Position behind the text */
        }

        .navbar__link:hover::after {
            transform: translate(-50%, -50%) scale(1); /* Scale to full size on hover */
        }
        
    </style>
</head>
<body>
    <header class="header">
        <nav class="navbar">
            <div class="navbar__container">
                <a href="/" id="navbar__logo"><i class='bx bxs-book-bookmark'></i></a>
                <div class="navbar__toggle" id="mobile-menu">
                    <span class="bar"></span> <span class="bar"></span>
                    <span class="bar"></span>
                </div>
                <ul class="navbar__menu">
                    <li class="navbar__item">
                        <a href="index2.php" class="navbar__links"> <!--Home--><i class='bx bx-home'></i></a>
                    </li>
                    <li class="navbar__item">
                        <!-- Button to go to the Add Book Page -->
                        <a href="add_book.html" class="navbar__links"><i class='bx bxs-book-add'></i></a>
                    </li>
                    <li class="navbar__item" id="login-link-item" style="display:none;">
                        <a href="login+register.html" class="navbar__links"> <!--Login--> <i class='bx bx-book-open'></i></a>
                    </li>
                    <li class="navbar__item" id="profile-link-item">
                        <a href="profile2.php" class="navbar__links"> <!--Profile--> <img src="<?php echo $profilePictureUrl; ?>" alt="Profile Image" id="profileImg"></a><!----------------------Use for Profile page------------------------>
                    </li>
                    <li class="navbar__item">
                        <a href="cart2.php" class="navbar__links"><!--Cart--> <i class='bx bx-cart'></i>
                            <span id="cart-count" class="cart-badge">0</span>
                        </a>
                    </li>
                    <li class="navbar__item" id="logout-link-item">
                            <a href="logout.php">
                            <button style="left: 15px; bottom: 5px;" class="Btn" id="profile-container" type="submit">
                                <div class="sign"><svg viewBox="0 0 512 512"><path d="M377.9 105.9L500.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L377.9 406.1c-6.4 6.4-15 9.9-24 9.9c-18.7 0-33.9-15.2-33.9-33.9l0-62.1-128 0c-17.7 0-32-14.3-32-32l0-64c0-17.7 14.3-32 32-32l128 0 0-62.1c0-18.7 15.2-33.9 33.9-33.9c9 0 17.6 3.6 24 9.9zM160 96L96 96c-17.7 0-32 14.3-32 32l0 256c0 17.7 14.3 32 32 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32z"></path></svg></div>
                                <div class="text">Logout</div>
                            </button></a>
                    </li>                    
                </ul>
            </div>
            <script src="js/app(nav).js"></script>
        </nav>
        
    </header>

        
    <div class="content">
        <h1>Welcome to the Online Bookstore</h1>
    </div>

    <!-- Wave Background -->
    <div>
        <div class="wave"></div>
        <div class="wave"></div>
        <div class="wave"></div>
    </div>
    <button id="darkModeToggle" class="dark-mode"><!--Toggle Dark Mode--><i class='bx bxs-moon'></i></button>   <select id="genreFilter" class="hero-btn" onchange="filterBooks()"><!--Genre Button-->
        <option value="">All Genres</option>
        <option value="Classic">Classic</option>
        <option value="Dystopian">Dystopian</option>
        <option value="Coming-of-age">Coming-of-age</option>
        <option value="Fantasy">Fantasy</option>
        <option value="Romance">Romance</option>
        <option value="Science Fiction">Science Fiction</option>
        <option value="Historical Fiction">Historical Fiction</option>
        <option value="Adventure">Adventure</option>
        <option value="Satire">Satire</option>
        <option value="Gothic Fiction">Gothic Fiction</option>
        <option value="Philosophical Fiction">Philosophical Fiction</option>
        <option value="Tragedy">Tragedy</option>
        <option value="Epic Poetry">Epic Poetry</option>
        <option value="Psychological Fiction">Psychological Fiction</option>
        <option value="Post-apocalyptic Fiction">Post-apocalyptic Fiction</option>
        <option value="Memoir">Memoir</option>
        <option value="Young Adult">Young Adult</option>
        <option value="Children's Fiction">Children's Fiction</option>
    </select>



    <!------Genre Dropdown---->
    <script>
        function filterBooks() {
            var input, filter, genreSelect, selectedGenre, bookList, bookItems, title, author, genre, i, txtValue;
            
            input = document.getElementById("mySearch");
            filter = input.value.toUpperCase();
            
            genreSelect = document.getElementById("genreFilter");
            selectedGenre = genreSelect.value.toUpperCase(); // Get selected genre
            
            bookList = document.querySelector('.book-list');
            bookItems = bookList.getElementsByClassName('book-item');
        
            for (i = 0; i < bookItems.length; i++) {
                title = bookItems[i].getElementsByTagName("h3")[0]; 
                author = bookItems[i].getElementsByTagName("p")[0];  
                genre = bookItems[i].getElementsByTagName("p")[1];  // Assuming genre is the second <p> tag
                
                txtValue = title.textContent || title.innerText;
                authorValue = author.textContent || author.innerText;
                genreValue = genre.textContent || genre.innerText;
        
                var matchesSearch = txtValue.toUpperCase().indexOf(filter) > -1 || authorValue.toUpperCase().indexOf(filter) > -1;
                var matchesGenre = selectedGenre === "" || genreValue.toUpperCase().includes(selectedGenre);
                
                if (matchesSearch && matchesGenre) {
                    bookItems[i].style.display = "";
                } else {
                    bookItems[i].style.display = "none";
                }
            }
        }
        
        // Attach event listener to search bar as well
        document.getElementById("mySearch").addEventListener("keyup", filterBooks);
    </script>
        

    <!------Search Bar-------->
    <script>
        function myFunction() {
            var input, filter, bookList, bookItems, title, author, i, txtValue;
            input = document.getElementById("mySearch");
            filter = input.value.toUpperCase();
            bookList = document.querySelector('.book-list'); // Get the container with book items
            bookItems = bookList.getElementsByClassName('book-item'); // Get all book items
        
            // Loop through all book items and hide those that don't match the search query
            for (i = 0; i < bookItems.length; i++) {
                title = bookItems[i].getElementsByTagName("h3")[0];  // Assuming book title is in <h3>
                author = bookItems[i].getElementsByTagName("p")[0];  // Assuming author is in first <p>
                
                // Check if the title or author matches the search query
                if (title || author) {
                    txtValue = title.textContent || title.innerText; // Get the title text
                    authorValue = author.textContent || author.innerText; // Get the author text
        
                    // If the search term is found in either the title or author, show the book, otherwise hide it
                    if (txtValue.toUpperCase().indexOf(filter) > -1 || authorValue.toUpperCase().indexOf(filter) > -1) {
                        bookItems[i].style.display = "";
                    } else {
                        bookItems[i].style.display = "none";
                    }
                }
            }
        }
    </script>
    <!------/Search Bar------->
    <div class="input-box">
        <input type="text" id="mySearch" class="hero-btn" onkeyup="myFunction()" placeholder="Search.." title="Type in a category"><i class='bx bx-search-alt'></i>
    </div>
    
    <script>
        // Dark Mode Toggle Script
        const darkModeToggle = document.getElementById('darkModeToggle');
        const body = document.body;
        const bookItems = document.querySelectorAll('.book-item'); // Select all book items

        darkModeToggle.addEventListener('click', () => {
            body.classList.toggle('dark-mode'); // Toggle the dark-mode class on the body

            // Loop through each book item and toggle the dark-mode class
            bookItems.forEach(item => {
                item.classList.toggle('dark-mode');
            });

            // Update button icon
            const icon = darkModeToggle.querySelector('i');
            if (body.classList.contains('dark-mode')) {
                icon.classList.remove('bxs-moon');
                icon.classList.add('bxs-sun'); // Switch to sun icon
            } else {
                icon.classList.remove('bxs-sun');
                icon.classList.add('bxs-moon'); // Switch back to moon icon
            }
        });

    </script>
    <div>
        <div class="book-list" id="bookContainer"></div>
        <br>
        <br>
        <p id="demo"></p>
    </div>
    <script src="js/app5.js"></script>

    <footer>
        <div class="footerContainer">
            <div class="socialIcons">
                <a href=""><i class='bx bxl-facebook-circle'></i></a>
                <a href=""><i class='bx bxl-instagram'></i></a>
                <a href=""><i class='bx bxl-twitter'></i></a>
                <a href=""><i class='bx bxl-google-plus'></i></a>
                <a href=""><i class='bx bxl-youtube'></i></a>
            </div>
            <div class="footerNav">
                <ul>
                    <li><a href="">Home</a></li>
                    <li><a href="">News</a></li>
                    <li><a href="">About</a></li>
                    <li><a href="">Contact Us</a></li>
                    <li><a href="">Our Team</a></li>
                </ul>
            </div>
            <div class="footerBottom">
                <p>Copyright &copy;2024; Designed by <span class="designer">Timi Ojo</span></p>
            </div>
        </div>
    </footer>

</body>
</html>