<?php
session_start(); // Start session to access user data

// Check if the user is logged in
if (isset($_SESSION['user_id']) && isset($_SESSION['username']) && isset($_SESSION['created_at'])) {
    $user_id = $_SESSION['user_id'];
    $username = $_SESSION['username'];
    $created_at = $_SESSION['created_at']; 
} else {
    echo "User is not logged in";
    header("Location: login+register.html");
    exit();
}

// Database connection parameters
$host = "localhost";
$user = "root";
$password = "";
$database = "bookstore";

try {
    $conn = new PDO("mysql:host=$host;dbname=$database", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => "Database connection failed: " . $e->getMessage()]);
    exit;
}

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Get request data
$requestBody = file_get_contents('php://input');
$data = json_decode($requestBody, true);

if (!isset($data['cart']) || empty($data['cart'])) {
    echo json_encode(['status' => 'error', 'message' => 'No cart data received.']);
    exit;
}

$cart = $data['cart'];
$total_price = 0;

try {
    $conn->beginTransaction();

    // Insert order into `orders`
    $orderStmt = $conn->prepare("INSERT INTO orders (user_id, total_price) VALUES (?, 0)"); // Start with total_price = 0
    $orderStmt->execute([$user_id]);
    $order_id = $conn->lastInsertId();

    // Prepare queries
    $bookQuery = $conn->prepare("SELECT book_id, price FROM books WHERE title = ?");
    $itemStmt = $conn->prepare("INSERT INTO order_items (order_id, book_id, quantity, price) VALUES (?, ?, ?, ?)");

    foreach ($cart as $item) {
        $title = $item['title'];
        $quantity = (int) $item['quantity'];

        // Get book_id and price
        $bookQuery->execute([$title]);
        $bookData = $bookQuery->fetch(PDO::FETCH_ASSOC);

        if (!$bookData) {
            throw new Exception("Book '$title' not found.");
        }

        $book_id = $bookData['book_id'];
        $price = $bookData['price'];
        $subtotal = $price * $quantity;
        $total_price += $subtotal;

        // Insert into `order_items`
        $itemStmt->execute([$order_id, $book_id, $quantity, $price]);
    }

    // Update total price in `orders`
    $updateOrderStmt = $conn->prepare("UPDATE orders SET total_price = ? WHERE order_id = ?");
    $updateOrderStmt->execute([$total_price, $order_id]);

    $conn->commit();

    echo json_encode(['status' => 'success', 'message' => 'Order placed successfully!']);

} catch (Exception $e) {
    $conn->rollBack();
    echo json_encode(['status' => 'error', 'message' => 'Failed to place order: ' . $e->getMessage()]);
}
?>
